"""
Router modules for User Service

各ルーターモジュールでFastAPIのAPIRouterを定義し、
main.pyでアプリケーションに登録する。
"""