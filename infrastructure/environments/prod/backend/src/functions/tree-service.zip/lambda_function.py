"""
Homebiyori Lambda Function - Sample Handler
Infrastructure connectivity test for tree-service
"""

import json
import os
from typing import Dict, Any

# Import from common layer
try:
    from homebiyori_common import (
        get_layer_info,
        create_success_response,
        create_error_response,
        log_event,
        get_hello_message
    )
    LAYER_AVAILABLE = True
except ImportError:
    LAYER_AVAILABLE = False
    print("Warning: Common layer not available")


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda handler for tree-service
    Tests infrastructure connectivity and layer integration
    """
    
    service_name = "tree-service"
    
    try:
        # Log the event for debugging
        if LAYER_AVAILABLE:
            log_event(event, context)
        else:
            print(f"EVENT: {json.dumps(event, ensure_ascii=False, default=str)}")
        
        # Get environment information
        environment_info = {
            "aws_region": os.environ.get("AWS_REGION", "unknown"),
            "function_name": context.function_name if context else "unknown",
            "function_version": context.function_version if context else "unknown",
            "memory_limit": context.memory_limit_in_mb if context else "unknown",
            "remaining_time": context.get_remaining_time_in_millis() if context else "unknown"
        }
        
        # Get layer information if available
        layer_info = None
        if LAYER_AVAILABLE:
            layer_info = get_layer_info()
        
        # Create response data
        response_data = {
            "service": service_name,
            "status": "healthy",
            "message": get_hello_message(service_name) if LAYER_AVAILABLE else f"Hello from tree-service! (Layer not available)",
            "layer_available": LAYER_AVAILABLE,
            "layer_info": layer_info,
            "environment": environment_info,
            "event_info": {
                "http_method": event.get("httpMethod", "N/A"),
                "path": event.get("path", "N/A"),
                "query_parameters": event.get("queryStringParameters"),
                "headers": event.get("headers", {}).get("User-Agent", "N/A")
            }
        }
        
        # Return success response
        if LAYER_AVAILABLE:
            return create_success_response(
                response_data,
                f"tree-service is operational"
            )
        else:
            return {
                "statusCode": 200,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                "body": json.dumps({
                    "success": True,
                    "message": f"tree-service is operational (without layer)",
                    "data": response_data
                }, ensure_ascii=False)
            }
            
    except Exception as e:
        error_message = f"Error in tree-service: {str(e)}"
        print(f"ERROR: {error_message}")
        
        if LAYER_AVAILABLE:
            return create_error_response(error_message)
        else:
            return {
                "statusCode": 500,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                "body": json.dumps({
                    "success": False,
                    "error": error_message
                }, ensure_ascii=False)
            }


# For testing locally
if __name__ == "__main__":
    test_event = {
        "httpMethod": "GET",
        "path": "/test",
        "queryStringParameters": None,
        "headers": {
            "User-Agent": "test-client"
        }
    }
    
    class MockContext:
        function_name = "tree-service-test"
        function_version = "$LATEST"
        memory_limit_in_mb = 256
        
        def get_remaining_time_in_millis(self):
            return 30000
    
    result = lambda_handler(test_event, MockContext())
    print(json.dumps(result, indent=2, ensure_ascii=False))