"""
Homebiyori Stripe Webhook Handler - Sample
Infrastructure connectivity test for handle-payment-failed
"""

import json
import os
from typing import Dict, Any

# Import from common layer
try:
    from homebiyori_common import (
        get_layer_info,
        create_success_response,
        create_error_response,
        log_event
    )
    LAYER_AVAILABLE = True
except ImportError:
    LAYER_AVAILABLE = False
    print("Warning: Common layer not available")


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Stripe Webhook handler for handle-payment-failed
    Tests EventBridge integration and layer connectivity
    """
    
    webhook_name = "handle-payment-failed"
    
    try:
        # Log the event for debugging
        if LAYER_AVAILABLE:
            log_event(event, context)
        else:
            print(f"EVENT: {json.dumps(event, ensure_ascii=False, default=str)}")
        
        # Parse EventBridge event
        event_source = event.get('source', 'unknown')
        detail_type = event.get('detail-type', 'unknown')
        detail = event.get('detail', {})
        
        # Get environment information
        environment_info = {
            "aws_region": os.environ.get("AWS_REGION", "unknown"),
            "function_name": context.function_name if context else "unknown",
            "function_version": context.function_version if context else "unknown",
            "memory_limit": context.memory_limit_in_mb if context else "unknown",
            "remaining_time": context.get_remaining_time_in_millis() if context else "unknown"
        }
        
        # Get layer information if available
        layer_info = None
        if LAYER_AVAILABLE:
            layer_info = get_layer_info()
        
        # Simulate webhook processing
        webhook_response = process_stripe_event(webhook_name, detail)
        
        # Create response data
        response_data = {
            "webhook": webhook_name,
            "status": "processed",
            "message": f"Stripe handle-payment-failed processed successfully",
            "layer_available": LAYER_AVAILABLE,
            "layer_info": layer_info,
            "environment": environment_info,
            "eventbridge_info": {
                "source": event_source,
                "detail_type": detail_type,
                "detail_keys": list(detail.keys()) if detail else []
            },
            "processing_result": webhook_response
        }
        
        # Return success response
        if LAYER_AVAILABLE:
            return create_success_response(
                response_data,
                f"Stripe handle-payment-failed webhook processed"
            )
        else:
            return {
                "statusCode": 200,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({
                    "success": True,
                    "message": f"Stripe handle-payment-failed webhook processed (without layer)",
                    "data": response_data
                }, ensure_ascii=False)
            }
            
    except Exception as e:
        error_message = f"Error in handle-payment-failed webhook: {str(e)}"
        print(f"ERROR: {error_message}")
        
        if LAYER_AVAILABLE:
            return create_error_response(error_message)
        else:
            return {
                "statusCode": 500,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({
                    "success": False,
                    "error": error_message
                }, ensure_ascii=False)
            }


def process_stripe_event(webhook_name: str, detail: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process Stripe webhook event based on type
    """
    
    if "payment-succeeded" in webhook_name:
        return {
            "action": "payment_confirmation",
            "message": "Payment success event would be processed here",
            "tasks": [
                "Update user subscription status",
                "Send confirmation email",
                "Log payment success"
            ]
        }
    elif "payment-failed" in webhook_name:
        return {
            "action": "payment_failure_handling",
            "message": "Payment failure event would be processed here",
            "tasks": [
                "Update user payment status",
                "Send payment retry notification",
                "Log payment failure"
            ]
        }
    elif "subscription-updated" in webhook_name:
        return {
            "action": "subscription_update",
            "message": "Subscription update event would be processed here",
            "tasks": [
                "Update user subscription tier",
                "Adjust feature access",
                "Log subscription change"
            ]
        }
    else:
        return {
            "action": "unknown_event",
            "message": f"Unknown webhook type: handle-payment-failed",
            "tasks": ["Log unknown event for investigation"]
        }


# For testing locally
if __name__ == "__main__":
    test_event = {
        "source": "aws.partner/stripe.com/test-account",
        "detail-type": "Test Stripe Event",
        "detail": {
            "id": "evt_test_webhook",
            "object": "event",
            "type": "test.webhook",
            "data": {
                "object": {
                    "id": "test_object_id"
                }
            }
        }
    }
    
    class MockContext:
        function_name = "handle-payment-failed-test"
        function_version = "$LATEST"
        memory_limit_in_mb = 256
        
        def get_remaining_time_in_millis(self):
            return 30000
    
    result = lambda_handler(test_event, MockContext())
    print(json.dumps(result, indent=2, ensure_ascii=False))