# Lambda package initialization
