"""
contact-service Lambda エントリーポイント

■Lambda設定■
Runtime: Python 3.11
Memory: 512MB
Timeout: 30秒
Environment Variables:
- CORE_TABLE_NAME: prod-homebiyori-core
- CHATS_TABLE_NAME: prod-homebiyori-chats
- FRUITS_TABLE_NAME: prod-homebiyori-fruits
- FEEDBACK_TABLE_NAME: prod-homebiyori-feedback
- LOG_LEVEL: INFO
- ENVIRONMENT: prod

■API Gateway統合■
- 認証: Cognito User Pool Authorizer
- CORS: 適切な設定
- レスポンス変換: Lambda Proxy統合
"""

import os
import json
from mangum import Mangum
from homebiyori_common.logger import get_logger

# FastAPIアプリケーションをインポート
from .main import app

# 構造化ログ設定
logger = get_logger(__name__)

# Mangumアダプターでラップ（API Gateway用）
# ルーティング設定はFastAPIで一元管理
handler = Mangum(app)

def lambda_handler(event, context):
    """
    Lambda エントリーポイント
    
    Args:
        event: API Gateway イベント
        context: Lambda コンテキスト
        
    Returns:
        API Gateway レスポンス
    """
    try:
        # リクエスト情報をログに記録
        logger.info(
            f"contact-service リクエスト開始",
            extra={
                "method": event.get("httpMethod"),
                "path": event.get("path"),
                "user_id": event.get("requestContext", {}).get("authorizer", {}).get("claims", {}).get("sub"),
                "request_id": context.aws_request_id
            }
        )
        
        # Mangumでリクエスト処理
        response = handler(event, context)
        
        # レスポンス情報をログに記録
        logger.info(
            f"contact-service リクエスト完了",
            extra={
                "status_code": response.get("statusCode"),
                "request_id": context.aws_request_id
            }
        )
        
        return response
        
    except Exception as e:
        # 予期しないエラーをログに記録
        logger.error(
            f"contact-service 予期しないエラー: {e}",
            extra={
                "request_id": context.aws_request_id,
                "error_type": type(e).__name__
            }
        )
        
        # エラーレスポンス返却
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization"
            },
            "body": json.dumps({
                "error": "internal_server_error",
                "message": "内部サーバーエラーが発生しました",
                "request_id": context.aws_request_id
            })
        }