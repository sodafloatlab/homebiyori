"""
Homebiyori Common Layer - Sample Module
Infrastructure connectivity test utilities
"""

import json
import datetime
from typing import Dict, Any


def get_layer_info() -> Dict[str, Any]:
    """
    Get information about the common layer
    """
    return {
        "layer_name": "homebiyori-common",
        "version": "1.0.0-sample",
        "build_time": datetime.datetime.now().isoformat(),
        "description": "Common utilities for Homebiyori Lambda functions",
        "components": [
            "error_handling",
            "response_formatter",
            "logging_utils",
            "aws_helpers"
        ]
    }


def create_success_response(data: Any, message: str = "Success") -> Dict[str, Any]:
    """
    Create standardized success response
    """
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
        },
        "body": json.dumps({
            "success": True,
            "message": message,
            "data": data,
            "timestamp": datetime.datetime.now().isoformat()
        }, ensure_ascii=False)
    }


def create_error_response(error: str, status_code: int = 500) -> Dict[str, Any]:
    """
    Create standardized error response
    """
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        },
        "body": json.dumps({
            "success": False,
            "error": error,
            "timestamp": datetime.datetime.now().isoformat()
        }, ensure_ascii=False)
    }


def log_event(event: Dict[str, Any], context: Any = None) -> None:
    """
    Log Lambda event for debugging
    """
    print(f"EVENT: {json.dumps(event, ensure_ascii=False, default=str)}")
    if context:
        print(f"CONTEXT: {context.function_name} - {context.aws_request_id}")


def get_hello_message(service_name: str) -> str:
    """
    Get hello message for a service
    """
    return f"Hello from {service_name}! Homebiyori infrastructure is working correctly."